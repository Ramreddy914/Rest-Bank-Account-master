# sudo chmod +x run-tests.sh

./gradlew clean test
