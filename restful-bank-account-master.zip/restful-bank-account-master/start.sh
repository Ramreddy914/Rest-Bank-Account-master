# sudo chmod +x start.sh

./gradlew bootRun
